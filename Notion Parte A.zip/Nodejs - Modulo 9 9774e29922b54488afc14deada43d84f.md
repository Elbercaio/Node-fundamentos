# Nodejs - Modulo 9:

[1 - [Definição de back-end e front-end](https://xpcorp.gama.academy/aluno/playlist/417/3323)](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/1%20-%20Definic%CC%A7a%CC%83o%20de%20back-end%20e%20front-end%2092299f4c16394411be6f2ddb222a9ff0.md)

[2 - Definição de Node](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/2%20-%20Definic%CC%A7a%CC%83o%20de%20Node%20353d3d2adcef4dd3a830a4e2bd2eab5a.md)

[[03 - Benchmark Node](https://xpcorp.gama.academy/aluno/playlist/417/3325)](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/03%20-%20Benchmark%20Node%2018e12299ddc548f48465be9cff8b3389.md)

[4 - Documentação Node](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/4%20-%20Documentac%CC%A7a%CC%83o%20Node%20c6e3c6fffdc44524ae36799a24e7d465.md)

[5 - **O problema de gerenciamento de pacotes**](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/5%20-%20O%20problema%20de%20gerenciamento%20de%20pacotes%20299970d805084dcbaea4ad9f63261f0b.md)

[6 - Documentação NPM](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/6%20-%20Documentac%CC%A7a%CC%83o%20NPM%20d33fe195d4b648588bb810cfa08dcb8c.md)

[7 - JavaScript](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/7%20-%20JavaScript%205f6ece1684fc400abddc69126540611f.md)

[8 - Documentação JS](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/8%20-%20Documentac%CC%A7a%CC%83o%20JS%20d8e3b9587e404202a97c9a447581441a.md)

[9 - TypeScript](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/9%20-%20TypeScript%20f0d8b70431b84e6bbd948e1956c22579.md)

[10 - Documentação TS](Nodejs%20-%20Modulo%209%209774e29922b54488afc14deada43d84f/10%20-%20Documentac%CC%A7a%CC%83o%20TS%2070d31f39ef3446b591b6d05f12f7a2a5.md)