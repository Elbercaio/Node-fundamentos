# 4 - Documentação Node

[https://nodejs.org/en/docs/](https://nodejs.org/en/docs/)

[https://nodejs.org/en/docs/guides/](https://nodejs.org/en/docs/guides/)

[https://devdocs.io/node/](https://devdocs.io/node/)

[https://stackoverflow.com](https://stackoverflow.com/)

[https://www.w3schools.com/nodejs/](https://www.w3schools.com/nodejs/)