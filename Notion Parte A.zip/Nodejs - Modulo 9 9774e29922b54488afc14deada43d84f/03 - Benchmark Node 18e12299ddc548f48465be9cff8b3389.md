# 03 - Benchmark Node

![Untitled](03%20-%20Benchmark%20Node%2018e12299ddc548f48465be9cff8b3389/Untitled.png)

![Untitled](03%20-%20Benchmark%20Node%2018e12299ddc548f48465be9cff8b3389/Untitled%201.png)

![Untitled](03%20-%20Benchmark%20Node%2018e12299ddc548f48465be9cff8b3389/Untitled%202.png)

![Untitled](03%20-%20Benchmark%20Node%2018e12299ddc548f48465be9cff8b3389/Untitled%203.png)

![Untitled](03%20-%20Benchmark%20Node%2018e12299ddc548f48465be9cff8b3389/Untitled%204.png)

![Untitled](03%20-%20Benchmark%20Node%2018e12299ddc548f48465be9cff8b3389/Untitled%205.png)