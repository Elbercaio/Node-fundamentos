# 7 - JavaScript

### O que é?

![Untitled](7%20-%20JavaScript%205f6ece1684fc400abddc69126540611f/Untitled.png)