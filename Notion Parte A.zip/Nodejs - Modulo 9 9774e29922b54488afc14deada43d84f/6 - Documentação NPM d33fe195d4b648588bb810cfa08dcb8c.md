# 6 - Documentação NPM

[https://docs.npmjs.com](https://docs.npmjs.com/)

[https://devdocs.io/npm/](https://devdocs.io/npm/)