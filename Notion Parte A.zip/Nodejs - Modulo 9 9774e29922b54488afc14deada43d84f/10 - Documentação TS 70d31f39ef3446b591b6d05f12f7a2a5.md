# 10 - Documentação TS

[https://www.typescriptlang.org/docs/](https://www.typescriptlang.org/docs/)