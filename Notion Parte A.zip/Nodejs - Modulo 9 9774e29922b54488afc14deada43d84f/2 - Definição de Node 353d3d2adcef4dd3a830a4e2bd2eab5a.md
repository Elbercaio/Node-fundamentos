# 2 - Definição de Node

### Porque Node?

![Untitled](2%20-%20Definic%CC%A7a%CC%83o%20de%20Node%20353d3d2adcef4dd3a830a4e2bd2eab5a/Untitled.png)

![Untitled](2%20-%20Definic%CC%A7a%CC%83o%20de%20Node%20353d3d2adcef4dd3a830a4e2bd2eab5a/Untitled%201.png)

Node tornou possível usar apenas uma linguagem para front e back end

### Definição

![Untitled](2%20-%20Definic%CC%A7a%CC%83o%20de%20Node%20353d3d2adcef4dd3a830a4e2bd2eab5a/Untitled%202.png)

### Benefícios

- Performance Excelente
- Escrito em JS simples e antigo
- Linguagem nova
- NPM
- Portátil
- Comunidade ativa