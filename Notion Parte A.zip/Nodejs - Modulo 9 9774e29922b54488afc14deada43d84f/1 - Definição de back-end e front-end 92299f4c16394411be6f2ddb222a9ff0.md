# 1 - Definição de back-end e front-end

### Servidor X Cliente

Cliente vai ao servidor e pede informações, nunca o contrario

![Untitled](1%20-%20Definic%CC%A7a%CC%83o%20de%20back-end%20e%20front-end%2092299f4c16394411be6f2ddb222a9ff0/Untitled.png)

### Server-side X Client-side

![Untitled](1%20-%20Definic%CC%A7a%CC%83o%20de%20back-end%20e%20front-end%2092299f4c16394411be6f2ddb222a9ff0/Untitled%201.png)

### Aplicações Server-side

![Untitled](1%20-%20Definic%CC%A7a%CC%83o%20de%20back-end%20e%20front-end%2092299f4c16394411be6f2ddb222a9ff0/Untitled%202.png)

### Evolução Client-side

![Untitled](1%20-%20Definic%CC%A7a%CC%83o%20de%20back-end%20e%20front-end%2092299f4c16394411be6f2ddb222a9ff0/Untitled%203.png)

### Linguagens Client-side

![Untitled](1%20-%20Definic%CC%A7a%CC%83o%20de%20back-end%20e%20front-end%2092299f4c16394411be6f2ddb222a9ff0/Untitled%204.png)

### Arquitetura client-server

![Untitled](1%20-%20Definic%CC%A7a%CC%83o%20de%20back-end%20e%20front-end%2092299f4c16394411be6f2ddb222a9ff0/Untitled%205.png)