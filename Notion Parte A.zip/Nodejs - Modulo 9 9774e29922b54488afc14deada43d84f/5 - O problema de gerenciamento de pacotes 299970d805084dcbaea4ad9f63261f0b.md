# 5 - O problema de gerenciamento de pacotes

### Para que serve?

![Untitled](5%20-%20O%20problema%20de%20gerenciamento%20de%20pacotes%20299970d805084dcbaea4ad9f63261f0b/Untitled.png)

### Problemas

![Untitled](5%20-%20O%20problema%20de%20gerenciamento%20de%20pacotes%20299970d805084dcbaea4ad9f63261f0b/Untitled%201.png)

### NPM

![Untitled](5%20-%20O%20problema%20de%20gerenciamento%20de%20pacotes%20299970d805084dcbaea4ad9f63261f0b/Untitled%202.png)

![Untitled](5%20-%20O%20problema%20de%20gerenciamento%20de%20pacotes%20299970d805084dcbaea4ad9f63261f0b/Untitled%203.png)